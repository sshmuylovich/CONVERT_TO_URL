# Convert_To_URL_
 
## Description
### Convert_To_URL is a library created for CSC 630 at Phillips Academy. It converts partial Email ID URLs by scanning and identifying ".edu" in the provided URLs. This helps to consolidate all the provided information into a single, homogenous format that allows for improved accessibility.
&nbsp;
 
## Install package using
### `pip install -i https://test.pypi.org/simple/ example-pkg-sshmuylovich`
&nbsp;
 
## Import and use the package in Python using
###
&nbsp;
 
## Authors
### Amy Jiang, Sima Shmuylovich, Koki Kapoor, Katie Wimmer

